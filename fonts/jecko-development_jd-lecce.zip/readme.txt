﻿JECKO DEVELOPMENT FONT

This font was created by Jecko Development (http://www.jeckodevelopment.com)
This font has a homepage where this archive and other versions may be found :: 
http://www.jeckodevelopment.com/fonts/
This font is released under a Creative Commons Attribution Non-commercial No Derivatives 
license (http://creativecommons.org/licenses/by-nc-nd/3.0/).
NOTE FOR FLASH USERS: This font is optimized for 
Flash. If the font in this archive is a pixel font, it is best displayed at a
font-size of 64.

Feel free to write us at info@jeckodevelopment.com or visit our website http://www.jeckodevelopment.com


